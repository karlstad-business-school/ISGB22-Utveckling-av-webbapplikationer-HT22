import { Component} from "react";

class Reaction extends Component {

    render() {

        return (
            <div>
                <img alt='Pokemon' src='https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/1.png' />
                <p>1</p>
                <p>Bulbasaur</p>
            </div>
        );

            
    }

}

export default Reaction;