import { Component } from "react";
import Header from './Header';
import Main from './Main';
import Footer from "./Footer";

class UIRoot extends Component {

    render() {

        let c = this.props.a;
        let d = this.props.b;
        let e = '7,5hp';
        let f = 'HT2022';
        let o = {i : c, j : d, k : e, l : f}

        return (
            <>
                <Header e={this.props.a} f={this.props.b} />
                <Main g={e} h={f} />
                <Footer {...o} />
            </>
        );
    }

}

export default UIRoot;