import { Component } from 'react';

class Main extends Component {

  processData(stringToProcess) {

    let firstNbr = parseInt( stringToProcess.substring( 0, 1 ) );
    let secondNbr = parseInt( stringToProcess.substring( 2, 3 ) );
    let red = firstNbr * secondNbr * secondNbr;
    let green = firstNbr * firstNbr * secondNbr;
    let blue = secondNbr * secondNbr * secondNbr;
    let css = { backgroundColor : 'rgb(' + red  + ',' + green + ',' + blue + ')' };
    
    return css;
  }
  render() {
    
    let i = this.props.g;
    let j = this.props.h;
    
    return ( 
      <main>
        <span>{i}</span>
        <span>{j}</span>
        <div style={this.processData(i)}>Detta är ett div-element!</div>
      </main> 
    );
  }

}

export default Main;