import { Component } from 'react';

class Footer extends Component {

  render() {

    let {i, j, k, l} = this.props;
    let m = l + ' ' + k + ' ' + j + ' ' + i;

    return ( 
          <>
            <footer>{m}</footer> 
          </>
      );
  }

}

export default Footer;