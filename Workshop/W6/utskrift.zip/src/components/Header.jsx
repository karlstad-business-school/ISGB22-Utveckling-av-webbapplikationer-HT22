import { Component } from 'react';

class Header extends Component {

  processData() {
    return this.props.f + ' (' + this.props.e + ')';
  }

  render() {
    return ( <header>{this.processData()}</header> );
  }

}

export default Header;