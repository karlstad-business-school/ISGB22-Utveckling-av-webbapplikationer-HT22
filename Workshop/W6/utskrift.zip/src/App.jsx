import { Component } from 'react';
import UIRoot from './components/UIRoot';

class App extends Component {

  render() {
    return ( <UIRoot a="ISGB22" b="Utveckling av webbapplikationer" /> );
  }

}

export default App;

