import { Component } from 'react';
import './Main.css';

class Main extends Component {

  render() {
   // let c = this.props.c;
   // let d = this.props.d;

    console.log( this.props );

    let {a, b, c, d} = this.props;

    console.log( a, b, c, d);  

    return ( <main>Detta är innehållet i main!</main> );
  }

}

export default Main;