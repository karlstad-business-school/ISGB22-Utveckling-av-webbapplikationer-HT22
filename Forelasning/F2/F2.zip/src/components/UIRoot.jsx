import { Component } from "react";
import Header from './Header';
import Main from './Main';
import Footer from "./Footer";

class UIRoot extends Component {

    render() {

        let data = { a : 5, b : 10, c : 15, d : 20 };

        return (
            <>
                <Header />
                <Main {...data}/>
                <Footer />
            </>
        );
    }

}

export default UIRoot;