import { Component } from 'react';

class Footer extends Component {

  render() {
    return ( <footer>{ Date.now() }</footer> );
  }

}

export default Footer;