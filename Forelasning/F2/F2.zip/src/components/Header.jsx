import { Component } from 'react';

class Header extends Component {

  render() {

    let a = 10;
    let b = 20;

    return ( <header>{a * b}</header> );
  }

}

export default Header;