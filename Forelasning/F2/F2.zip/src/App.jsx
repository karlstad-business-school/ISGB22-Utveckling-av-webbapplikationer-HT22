import { Component } from 'react';
import UIRoot from './components/UIRoot';

class App extends Component {

  render() {
    return ( <UIRoot /> );
  }

}

export default App;

